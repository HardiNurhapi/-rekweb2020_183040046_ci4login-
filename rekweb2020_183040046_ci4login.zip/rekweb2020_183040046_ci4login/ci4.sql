-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2020 at 03:36 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4`
--

-- --------------------------------------------------------

--
-- Table structure for table `komik`
--

CREATE TABLE `komik` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `sampul` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `komik`
--

INSERT INTO `komik` (`id`, `judul`, `slug`, `penulis`, `penerbit`, `sampul`, `created_at`, `updated_at`) VALUES
(1, 'Naruto', 'Naruto', 'Masashi Kishimoto', 'Gramedia', '1.jpg', NULL, NULL),
(2, 'Marvel', 'Marvel', 'Yūki Tabata', 'Stan Lee', '2.jpg', NULL, NULL),
(3, 'Doraemon ', 'Doraemon', 'Fujiko F. Fujio', 'Gramedia', '3.jpg', '2020-08-22 22:32:23', '2020-08-22 22:32:23');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2020-08-24-061807', 'App\\Database\\Migrations\\Orang', 'default', 'App', 1602931075, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orang`
--

CREATE TABLE `orang` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orang`
--

INSERT INTO `orang` (`id`, `nama`, `alamat`, `created_at`, `updated_at`) VALUES
(1, 'Karsana Permadi S.T.', 'Kpg. Kusmanto No. 363, Administrasi Jakarta Selatan 89091, BaBel', '1978-05-08 10:34:37', '1979-02-22 04:25:05'),
(2, 'Endah Novi Prastuti', 'Ki. Yosodipuro No. 313, Banda Aceh 85583, Bali', '1989-10-13 12:48:29', '1976-11-16 00:57:34'),
(3, 'Satya Salahudin S.Pt', 'Jln. Salatiga No. 2, Mataram 11079, SumUt', '1992-04-26 09:02:45', '1971-04-25 06:55:13'),
(4, 'Usman Maheswara', 'Ki. Sudiarto No. 992, Bekasi 50853, Papua', '1985-05-15 10:27:28', '1989-07-25 09:42:55'),
(5, 'Olivia Uyainah', 'Ki. Bakti No. 874, Pekanbaru 79793, Bali', '2005-07-14 13:47:38', '1971-08-11 23:33:03'),
(6, 'Artanto Prakasa S.Pt', 'Ds. Bakit  No. 621, Cirebon 70486, SulTra', '2003-02-24 01:19:10', '2011-06-21 03:02:55'),
(7, 'Salimah Vicky Hartati S.Kom', 'Jln. Sutan Syahrir No. 989, Administrasi Jakarta Selatan 80123, Lampung', '1993-10-17 11:44:02', '2004-12-30 14:52:42'),
(8, 'Virman Adriansyah', 'Jr. Gambang No. 526, Pematangsiantar 69179, SulSel', '1995-10-03 14:31:14', '1986-12-05 10:32:38'),
(9, 'Jaswadi Jati Lazuardi', 'Kpg. Abdul. Muis No. 412, Depok 66847, Papua', '1976-10-19 02:47:29', '1988-09-11 22:14:58'),
(10, 'Latika Lailasari', 'Ds. Haji No. 251, Probolinggo 82451, Gorontalo', '2012-12-18 01:19:41', '1995-05-15 16:10:44'),
(11, 'Azalea Mandasari', 'Kpg. Yogyakarta No. 267, Bontang 34537, KalTeng', '1980-06-02 22:00:10', '1979-12-10 05:02:22'),
(12, 'Ilyas Firgantoro', 'Kpg. Achmad Yani No. 560, Pangkal Pinang 45090, KalTeng', '2002-07-28 15:34:19', '1991-01-22 21:38:45'),
(13, 'Putri Wijayanti', 'Ds. Sutoyo No. 548, Payakumbuh 60398, Lampung', '2017-12-04 04:17:48', '1984-06-28 16:10:49'),
(14, 'Janet Zahra Puspasari S.Ked', 'Psr. Karel S. Tubun No. 845, Pasuruan 36047, Lampung', '2011-08-26 15:46:31', '1989-01-07 19:05:46'),
(15, 'Betania Yance Zulaika M.Ak', 'Psr. Teuku Umar No. 338, Surakarta 83978, Riau', '1977-06-20 09:44:46', '2016-07-27 08:58:40'),
(16, 'Elma Mandasari', 'Dk. Cemara No. 10, Bitung 56019, MalUt', '2020-09-19 03:43:46', '2003-07-29 19:20:58'),
(17, 'Diana Agustina', 'Kpg. Jend. Sudirman No. 56, Lubuklinggau 70769, MalUt', '2002-06-09 03:13:30', '2013-10-27 19:50:40'),
(18, 'Hardana Hidayat S.Farm', 'Ki. Bhayangkara No. 937, Tanjung Pinang 19583, KalSel', '1974-03-21 02:40:18', '2009-10-04 19:23:41'),
(19, 'Ratih Diana Zulaika S.Kom', 'Kpg. Barasak No. 300, Banjar 52797, SumBar', '1977-05-01 17:52:17', '1984-10-17 14:14:45'),
(20, 'Vivi Nadia Wijayanti', 'Jr. W.R. Supratman No. 493, Administrasi Jakarta Barat 15436, Bengkulu', '2014-07-14 03:29:07', '1980-04-29 07:45:08'),
(21, 'Manah Adiarja Wibisono', 'Gg. Basuki Rahmat  No. 195, Pontianak 77300, NTB', '2008-06-08 05:47:53', '2013-01-17 09:34:34'),
(22, 'Mahdi Prabowo', 'Dk. Cikapayang No. 847, Mataram 32956, NTB', '1972-04-14 08:53:44', '1976-10-01 19:05:39'),
(23, 'Artanto Cawisono Hidayat S.Pd', 'Gg. Jambu No. 983, Pasuruan 29864, Maluku', '1976-11-22 06:42:23', '2001-09-16 15:13:15'),
(24, 'Raina Kuswandari S.Psi', 'Ds. Kartini No. 355, Malang 52673, NTB', '1985-05-14 18:32:33', '1971-03-18 06:14:56'),
(25, 'Najam Galih Habibi S.Pt', 'Ki. Yoga No. 403, Tegal 50265, SumUt', '1992-07-29 07:25:29', '2017-05-23 06:41:58'),
(26, 'Zulfa Ajeng Nasyiah', 'Dk. Sugiono No. 466, Tual 95652, NTB', '1976-10-23 12:31:13', '1988-05-18 20:55:24'),
(27, 'Yunita Padmasari', 'Ds. Sugiyopranoto No. 643, Tanjung Pinang 31640, KepR', '2004-02-18 15:47:06', '1996-04-13 00:57:24'),
(28, 'Oni Novitasari', 'Jr. Cikapayang No. 467, Padang 38039, KalTeng', '2002-11-20 03:47:28', '1997-04-23 11:56:23'),
(29, 'Cagak Simanjuntak', 'Dk. Diponegoro No. 394, Bau-Bau 92283, NTB', '1996-04-16 19:58:44', '1987-10-31 18:06:29'),
(30, 'Cakrabirawa Hutagalung', 'Ds. Astana Anyar No. 778, Batam 99282, Lampung', '1997-04-13 10:12:30', '1979-01-19 16:16:45'),
(31, 'Wage Dono Hidayanto S.Kom', 'Kpg. Ir. H. Juanda No. 195, Payakumbuh 57237, SumUt', '1994-11-05 03:43:23', '1978-02-07 13:13:03'),
(32, 'Patricia Widiastuti', 'Dk. Baan No. 158, Sibolga 25466, SumUt', '2011-11-16 03:38:40', '2020-04-27 13:04:14'),
(33, 'Surya Maryadi S.H.', 'Psr. Samanhudi No. 940, Subulussalam 46133, Jambi', '1984-08-12 15:33:52', '1993-04-09 00:12:16'),
(34, 'Surya Ismail Permadi S.IP', 'Ds. Bappenas No. 746, Sorong 69377, Jambi', '1989-11-18 04:47:19', '1991-07-25 10:03:54'),
(35, 'Ajiman Sirait S.Ked', 'Dk. R.E. Martadinata No. 620, Samarinda 74231, JaTim', '1974-05-04 21:24:27', '1997-09-23 21:32:23'),
(36, 'Qori Oktaviani', 'Ki. Fajar No. 745, Sawahlunto 68571, KalTim', '2007-12-13 09:21:37', '1996-07-26 01:10:04'),
(37, 'Cayadi Sinaga M.Kom.', 'Jln. Samanhudi No. 893, Palangka Raya 44465, Gorontalo', '1976-07-16 07:29:40', '1985-11-09 21:08:48'),
(38, 'Wawan Uwais', 'Kpg. Otista No. 49, Administrasi Jakarta Timur 55654, Maluku', '1983-11-26 06:48:49', '1990-08-20 05:49:34'),
(39, 'Danuja Nashiruddin', 'Dk. Yogyakarta No. 842, Kupang 17688, Bali', '2012-06-15 02:31:01', '1983-08-21 19:19:47'),
(40, 'Cindy Padmasari S.E.', 'Ds. Merdeka No. 299, Yogyakarta 54684, KalSel', '2005-06-07 04:58:43', '1996-11-08 12:01:13'),
(41, 'Warsa Winarno', 'Ds. Jend. Sudirman No. 764, Medan 49758, Riau', '2002-01-12 11:04:58', '1989-05-07 13:50:56'),
(42, 'Edward Akarsana Kusumo', 'Ki. Samanhudi No. 410, Bukittinggi 79807, SulTeng', '2014-03-15 16:45:48', '2012-09-10 08:13:01'),
(43, 'Tari Hilda Pudjiastuti S.Ked', 'Ki. Sutan Syahrir No. 654, Semarang 86797, JaTim', '2010-05-14 19:08:37', '1976-09-05 01:19:43'),
(44, 'Silvia Laksita S.Ked', 'Ds. Baung No. 801, Ambon 71447, JaTeng', '1984-04-01 14:49:18', '1973-12-07 03:30:04'),
(45, 'Nabila Vanesa Melani M.Farm', 'Jr. Suryo Pranoto No. 779, Probolinggo 90388, PapBar', '1973-12-04 06:08:05', '2008-07-18 04:41:13'),
(46, 'Xanana Unggul Waluyo', 'Ds. Raya Setiabudhi No. 114, Palopo 87048, Maluku', '1983-06-05 21:01:21', '1992-01-09 13:56:45'),
(47, 'Prabu Halim', 'Ds. Rajawali Barat No. 121, Gunungsitoli 32410, SulSel', '1975-05-14 00:20:17', '2008-11-03 02:21:25'),
(48, 'Gara Ramadan', 'Ds. Merdeka No. 931, Semarang 73005, NTT', '1984-08-19 07:14:03', '1982-04-07 18:08:23'),
(49, 'Pia Palastri M.TI.', 'Jln. Imam Bonjol No. 239, Tangerang 99876, Banten', '2003-08-12 17:04:13', '2008-05-14 12:31:54'),
(50, 'Imam Wasita', 'Psr. Sam Ratulangi No. 762, Sorong 54487, NTB', '1989-04-02 18:32:36', '1993-05-29 12:51:11'),
(51, 'Labuh Ramadan', 'Jln. Dahlia No. 854, Bandung 64478, KepR', '2004-03-13 08:40:36', '1990-02-06 04:25:34'),
(52, 'Purwa Dariati Sirait S.H.', 'Jln. Rumah Sakit No. 156, Tangerang 22897, SulBar', '2008-07-11 20:12:51', '2010-08-01 17:19:40'),
(53, 'Zamira Mayasari', 'Ki. Gedebage Selatan No. 274, Pariaman 31378, KalBar', '1980-04-04 11:16:55', '1983-05-01 01:45:07'),
(54, 'Bahuwirya Radika Marbun M.TI.', 'Jr. Casablanca No. 528, Tasikmalaya 87203, NTB', '1994-11-10 19:17:31', '1997-05-07 02:42:45'),
(55, 'Mulyono Soleh Prayoga S.H.', 'Ds. Bakit  No. 587, Bitung 88196, SumUt', '2014-01-04 01:48:42', '2014-09-19 02:14:28'),
(56, 'Lurhur Mulyono Uwais S.Pd', 'Ds. S. Parman No. 494, Gunungsitoli 33938, BaBel', '1979-02-08 22:47:29', '1980-11-05 18:55:51'),
(57, 'Vera Zelaya Pertiwi S.T.', 'Jr. Dahlia No. 300, Administrasi Jakarta Selatan 64660, Banten', '1977-04-04 19:56:06', '2008-05-29 07:17:55'),
(58, 'Febi Laksita', 'Jr. Qrisdoren No. 668, Administrasi Jakarta Pusat 28204, KalTeng', '2019-07-09 23:16:58', '1983-01-28 19:37:15'),
(59, 'Jarwa Putra S.Ked', 'Gg. Bara Tambar No. 42, Metro 43873, Maluku', '1994-07-30 16:00:04', '1997-06-01 07:26:24'),
(60, 'Dina Rahayu', 'Kpg. Adisucipto No. 93, Parepare 82621, DKI', '1992-11-03 03:08:02', '1971-09-17 09:09:11'),
(61, 'Jono Hakim M.Pd', 'Kpg. Samanhudi No. 361, Cirebon 30828, KalBar', '1985-05-23 17:51:04', '1983-01-16 03:12:13'),
(62, 'Among Kuswoyo', 'Ki. Tentara Pelajar No. 848, Tegal 82384, SulTra', '1999-01-16 20:09:19', '1980-01-12 20:16:49'),
(63, 'Taufan Jagaraga Tarihoran S.IP', 'Jr. PHH. Mustofa No. 619, Bontang 23630, Gorontalo', '1970-10-24 04:09:42', '1971-06-12 11:47:02'),
(64, 'Lukita Mustofa M.Ak', 'Ds. Baranangsiang No. 759, Balikpapan 72485, JaBar', '2000-03-24 07:31:01', '1974-08-25 04:16:17'),
(65, 'Tira Nuraini', 'Kpg. Bahagia  No. 192, Yogyakarta 60398, SumSel', '1982-09-02 06:01:33', '2012-05-04 04:40:21'),
(66, 'Halim Lega Gunawan', 'Kpg. Bak Mandi No. 668, Cilegon 21480, JaTeng', '1999-03-08 03:13:11', '1994-10-06 03:15:23'),
(67, 'Lintang Lestari M.TI.', 'Kpg. Jaksa No. 103, Yogyakarta 29938, SumBar', '1977-05-18 16:17:13', '1990-07-15 20:36:11'),
(68, 'Zulfa Ratna Wastuti S.E.I', 'Ki. Eka No. 559, Sibolga 36853, JaTeng', '1981-04-24 15:19:52', '1999-02-04 06:38:17'),
(69, 'Zulfa Utami', 'Gg. Sam Ratulangi No. 60, Pagar Alam 83715, SulBar', '2009-01-03 11:26:28', '1984-11-11 00:46:27'),
(70, 'Laila Hassanah', 'Jr. Batako No. 704, Bandung 99577, KalBar', '2006-09-20 13:08:03', '2010-12-17 01:23:17'),
(71, 'Kemba Yahya Kurniawan S.H.', 'Dk. Sentot Alibasa No. 224, Batu 17642, Lampung', '1974-06-19 14:53:41', '2006-07-23 23:41:26'),
(72, 'Karman Gatra Wacana S.T.', 'Jln. Pelajar Pejuang 45 No. 11, Blitar 87055, JaTeng', '2004-12-22 15:13:30', '2016-12-20 23:36:00'),
(73, 'Ika Suci Puspasari', 'Dk. Ujung No. 981, Depok 55170, KalUt', '1971-09-06 19:09:47', '2005-07-10 12:11:53'),
(74, 'Cawisadi Jasmani Pangestu', 'Psr. Kyai Gede No. 801, Depok 73175, SulTeng', '1996-10-25 05:40:58', '1977-08-22 20:12:51'),
(75, 'Cici Laksita S.Pt', 'Dk. Abdul No. 494, Mojokerto 25503, SulTra', '1981-08-29 16:44:03', '2007-12-17 21:19:32'),
(76, 'Icha Mandasari S.Pd', 'Ki. Uluwatu No. 437, Tanjung Pinang 10773, Jambi', '1991-12-18 06:34:27', '2016-05-26 04:21:40'),
(77, 'Gasti Puspita', 'Gg. B.Agam Dlm No. 366, Padangsidempuan 38586, NTT', '1974-06-04 20:24:17', '1978-07-23 17:11:27'),
(78, 'Galih Martana Firmansyah', 'Kpg. Bakau No. 242, Administrasi Jakarta Barat 66361, KalTeng', '1991-05-26 07:12:52', '2006-05-06 02:17:05'),
(79, 'Padmi Mayasari S.T.', 'Jr. R.E. Martadinata No. 185, Subulussalam 76104, SumSel', '1984-07-19 15:35:56', '1996-09-02 22:47:36'),
(80, 'Umar Kusumo', 'Psr. Salatiga No. 702, Banjarbaru 97030, KalTim', '1989-02-28 15:39:19', '1987-11-08 23:46:43'),
(81, 'Yosef Irnanto Dabukke', 'Gg. Bagis Utama No. 291, Binjai 78999, NTB', '1994-10-06 20:17:13', '1971-12-26 16:59:16'),
(82, 'Oni Kusmawati', 'Dk. Gading No. 733, Bima 66666, Bengkulu', '1972-06-11 19:08:58', '2001-02-14 07:24:05'),
(83, 'Cici Ina Kusmawati', 'Kpg. Moch. Yamin No. 792, Palu 73950, SumBar', '1973-12-27 05:30:36', '2016-01-08 04:52:58'),
(84, 'Aris Kurniawan', 'Jln. Orang No. 372, Kotamobagu 38766, Jambi', '2004-10-19 03:45:33', '2006-07-23 16:37:48'),
(85, 'Rahayu Yolanda S.Pd', 'Ds. PHH. Mustofa No. 979, Medan 15881, NTB', '2003-05-22 04:57:01', '2015-02-05 17:41:40'),
(86, 'Raina Wulandari', 'Ds. Pattimura No. 672, Pekanbaru 39590, KalBar', '1984-01-30 21:50:02', '2020-08-21 09:06:40'),
(87, 'Nadine Maimunah Handayani S.Psi', 'Psr. Jagakarsa No. 108, Parepare 23689, Papua', '1988-04-09 05:38:33', '2011-07-22 02:11:12'),
(88, 'Uli Aryani', 'Ki. Yap Tjwan Bing No. 733, Tegal 45055, KalTim', '1971-04-26 22:30:20', '1983-11-06 17:22:45'),
(89, 'Victoria Hasanah S.E.', 'Dk. Dago No. 260, Padang 72495, KalBar', '2000-09-02 16:06:03', '1978-05-08 06:03:03'),
(90, 'Kartika Novitasari', 'Ds. Babadak No. 518, Bukittinggi 81581, SulSel', '1975-10-04 12:23:26', '1997-05-26 23:45:23'),
(91, 'Cindy Dian Puspasari S.Ked', 'Kpg. Abdul No. 923, Tanjungbalai 18356, NTT', '1996-10-18 01:54:08', '2000-03-10 15:32:51'),
(92, 'Ilsa Ina Lailasari', 'Kpg. Baung No. 671, Cilegon 13258, NTB', '2017-06-14 12:56:08', '1991-01-21 02:55:04'),
(93, 'Gandi Harja Iswahyudi', 'Psr. Abdullah No. 28, Gunungsitoli 38912, PapBar', '1984-11-04 13:35:23', '1975-12-31 16:17:42'),
(94, 'Lalita Raisa Nasyiah S.Gz', 'Gg. Setiabudhi No. 374, Administrasi Jakarta Pusat 74116, PapBar', '1974-02-09 09:44:42', '2020-08-18 15:07:22'),
(95, 'Maras Aris Hutapea S.Pt', 'Psr. Wahid No. 2, Denpasar 79941, DKI', '1993-12-31 02:39:58', '2009-05-09 15:50:16'),
(96, 'Rudi Budiman', 'Ki. Barasak No. 151, Sungai Penuh 92284, NTB', '1979-08-29 11:08:17', '2008-09-04 10:13:28'),
(97, 'Rahayu Agustina', 'Jln. Otista No. 897, Ternate 42644, KalTeng', '1973-06-03 09:28:02', '1972-12-15 08:09:54'),
(98, 'Emas Situmorang', 'Ki. Ki Hajar Dewantara No. 393, Mojokerto 31616, DIY', '1988-08-01 15:41:25', '1994-03-29 16:54:23'),
(99, 'Ami Fujiati', 'Jln. Elang No. 787, Bekasi 78639, Jambi', '2003-01-21 21:11:02', '1990-10-24 21:12:25'),
(100, 'Cakrawala Dabukke', 'Ki. Baranang Siang Indah No. 813, Pontianak 35862, BaBel', '1977-07-08 07:00:41', '1976-06-24 09:13:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `komik`
--
ALTER TABLE `komik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orang`
--
ALTER TABLE `orang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `komik`
--
ALTER TABLE `komik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orang`
--
ALTER TABLE `orang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
