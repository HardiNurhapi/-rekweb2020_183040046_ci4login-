<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
  <div class="row">
    <div class="col">
      <h2>About Me.</h2>
      <p>Halo nama saya Hardi Nurhapi saya tinggal di Sumedang saya kuliah di Universitas Pasundan Bandung.</p>
    </div>
  </div>
</div>
<?= $this->endSection() ?>