<?php

namespace App\Controllers;

class Pages extends BaseController
{
  public function index()
  {
    $data = [
      'title' => "Hardi Nurhapi Home Page"
    ];
    return view('pages/home', $data);
  }
  public function about($nama = 'Hardi Nurhapi', $umur = 21)
  {
    $data = [
      'title' => "About Me",
      'nama' => $nama,
      'umur' => $umur
    ];
    return view('pages/about', $data);
  }
  public function contact()
  {
    $data = [
      'title' => "Contact Us",
      'alamat' => [
        [
          'tipe' => '081223824794',
          'alamat' => 'Kp.Sukamaju Ds.Banjarsari Kec.Jatinunggal',
          'kota' => 'Sumedang'
        ],
        [
          'tipe' => 'Universitas Pasundan',
          'alamat' => 'Jl. Dr Setiabudi No.193',
          'kota' => 'Bandung'
        ]
      ]
    ];
    return view('pages/contact', $data);
  }
}
